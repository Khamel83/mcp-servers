package test_repo;

public class Utils {
    public static void printHello() {
        System.out.println("Hello from Utils!");
    }
}

<?php

function helperFunction(): void {
    echo "Helper function was called.";
}

?> 
"""
Examples package for demonstrating test_repo module usage.
"""
